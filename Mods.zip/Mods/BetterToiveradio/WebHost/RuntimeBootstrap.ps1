﻿$ErrorActionPreference = 'Stop'
$mutex = New-Object Threading.Mutex($false, 'Local\BetterToiveRadio.RuntimeSetup')
$locked = $false
try {
    try { $locked = $mutex.WaitOne(1800000) } catch [Threading.AbandonedMutexException] { $locked = $true }
    if (-not $locked) { throw 'Outra preparacao ainda esta em andamento.' }
    $source = @'
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;

namespace BetterToiveradio.Core
{
    // A small streaming container supported by Unity's .NET 3.5 profile.
    internal static class DependencyBundle
    {
        internal static void Extract(Stream compressed, string folder, Func<bool> cancelled)
        {
            Directory.CreateDirectory(folder);
            string staging = Path.Combine(folder, ".setup-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(staging);
            List<string> names = new List<string>();
            Dictionary<string, byte[]> hashes = new Dictionary<string, byte[]>(StringComparer.OrdinalIgnoreCase);
            try
            {
                using (GZipStream gzip = new GZipStream(compressed, CompressionMode.Decompress))
                using (BinaryReader reader = new BinaryReader(gzip))
                {
                    if (reader.ReadInt32() != 0x42545235) throw new IOException("Invalid dependency bundle.");
                    int count = reader.ReadInt32();
                    if (count < 1 || count > 64) throw new IOException("Invalid file count.");
                    long total = 0; byte[] buffer = new byte[65536];
                    for (int i = 0; i < count; i++)
                    {
                        string name = reader.ReadString(); long length = reader.ReadInt64(); byte[] hash = reader.ReadBytes(32);
                        if (name.Length == 0 || name.Length > 120 || name.IndexOfAny(new[] {'/', '\\', ':'}) >= 0
                            || name.StartsWith(".") || Path.GetFileName(name) != name || hashes.ContainsKey(name))
                            throw new IOException("Unsafe bundle filename.");
                        total += length;
                        if (length < 0 || length > 256 * 1024 * 1024 || total > 512 * 1024 * 1024 || hash.Length != 32)
                            throw new IOException("Invalid bundle size.");
                        string file = Path.Combine(staging, name);
                        using (FileStream output = File.Create(file))
                        {
                            long remaining = length;
                            while (remaining > 0)
                            {
                                if (cancelled()) throw new IOException("Setup cancelled.");
                                int read = reader.Read(buffer, 0, (int)Math.Min(buffer.Length, remaining));
                                if (read == 0) throw new EndOfStreamException();
                                output.Write(buffer, 0, read); remaining -= read;
                            }
                        }
                        if (!Matches(file, hash)) throw new IOException("Dependency checksum mismatch.");
                        names.Add(name); hashes.Add(name, hash);
                    }
                    if (reader.Read() != -1) throw new IOException("Unexpected bundle data.");
                }
                // Nothing is replaced before every embedded file has been checked.
                foreach (string name in names)
                {
                    if (cancelled()) throw new IOException("Setup cancelled.");
                    string destination = Path.Combine(folder, name), source = Path.Combine(staging, name);
                    if (File.Exists(destination))
                    {
                        if (Matches(destination, hashes[name])) continue;
                        File.Replace(source, destination, destination + ".before-setup");
                    }
                    else File.Move(source, destination);
                }
            }
            finally { if (Directory.Exists(staging)) Directory.Delete(staging, true); }
        }
        private static bool Matches(string file, byte[] expected)
        {
            using (SHA256 sha = SHA256.Create())
            using (FileStream input = File.OpenRead(file))
            {
                byte[] actual = sha.ComputeHash(input);
                for (int i = 0; i < expected.Length; i++) if (actual[i] != expected[i]) return false;
                return true;
            }
        }
    }
}

public static class BtrSetupBridge {
    public static void Extract(string payload, string folder) {
        using (System.IO.Stream input = System.IO.File.OpenRead(payload))
            BetterToiveradio.Core.DependencyBundle.Extract(input, folder, () => false);
    }
}
'@
    Add-Type -TypeDefinition $source
    [BtrSetupBridge]::Extract((Join-Path $PSScriptRoot '.dependencies.gz'), $PSScriptRoot)
    & (Join-Path $PSScriptRoot 'PrepareRuntime.ps1')
    exit $LASTEXITCODE
} catch {
    $_.Exception.ToString() | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'setup.log') -Encoding UTF8
    exit 1
} finally {
    if ($locked) { $mutex.ReleaseMutex() }
    $mutex.Dispose()
}

